#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[1] Diferencia as cores de "Aprovado" (verde) e "Concluído" (azul/tinta),
    que hoje sao o MESMO verde e confundem.

[2] Admin pode editar os campos do perfil do assessor (para aplicar correcoes
    que o RH pediu — ex.: contrato social errado). Os campos que alimentam os
    FILTROS sao atualizados nos DOIS lugares: as colunas de assessor_publicacoes
    (que os filtros leem com prioridade) E o dados_publicacao (o snapshot).
    Assim a correcao aparece no filtro certo.

    Novo endpoint: PATCH /assessor-aprovacoes/:id  (requireRole admin)
      body: { nome, codigo_assessor, unidade, contrato_social, foto_url }
      - grava nas colunas + no dados_publicacao
      - marca editado_por_rh = true (o campo ja existia na tabela, nunca usado)

Alvos: forms.ts (endpoint), config.js (cores), validacao-assessores.html (UI).
Idempotente, backups .bak-editperfil.
"""
import io, os, sys, glob, re

def _r(cs):
    for c in cs:
        p=os.path.normpath(c)
        if os.path.exists(p): return p
    return None
CFG=_r(["artifacts/api-server/public/config.js","public/config.js"])
VAL=_r(["artifacts/api-server/public/validacao-assessores.html","public/validacao-assessores.html"])
ROTAS=glob.glob("artifacts/api-server/src/routes/*.ts")+glob.glob("src/routes/*.ts")
APR=next((p for p in ROTAS if '"/assessor-aprovacoes/:id/decisao"' in io.open(p,encoding="utf-8").read()),None)
if not all([CFG,VAL,APR]): sys.exit("arquivos nao encontrados")

def salvar(p,antes,depois,tag):
    b=p+".bak-editperfil"
    if not os.path.exists(b): io.open(b,"w",encoding="utf-8").write(antes)
    io.open(p,"w",encoding="utf-8").write(depois); print(tag)

# ═══ [1] cores: Concluido em azul-tinta (as cores de status estao no HTML de validacao) ═══
cv=io.open(VAL,encoding="utf-8").read()
if "'publicado':            { label: 'Concluído',            bg: '#dbeafe'" in cv:
    print("[1] JA APLICADO.")
else:
    OLD_COR="'publicado':            { label: 'Concluído',            bg: '#dcfce7', fg: '#14532d', accent: '#14532d' },"
    if cv.count(OLD_COR)!=1: sys.exit("ABORTADO [1]: ancora de cor (%d)"%cv.count(OLD_COR))
    NEW_COR="'publicado':            { label: 'Concluído',            bg: '#dbeafe', fg: '#1e40af', accent: '#1d4ed8' },"
    salvar(VAL,cv,cv.replace(OLD_COR,NEW_COR,1),"[1] OK — Concluído agora é azul (distinto de Aprovado)")

# ═══ [2a] backend: PATCH para editar o perfil (admin) ═══
a=io.open(APR,encoding="utf-8").read()
if 'router.patch("/assessor-aprovacoes/:id"' in a:
    print("[2a] JA APLICADO.")
else:
    ANC='router.post("/assessor-aprovacoes/:id/decisao"'
    if a.count(ANC)!=1: sys.exit("ABORTADO [2a]: ancora do POST decisao")
    ENDPOINT='''// PATCH /assessor-aprovacoes/:id — admin corrige os dados do perfil (ex.: contrato
// social errado). Atualiza as COLUNAS (que os filtros leem) e o dados_publicacao.
router.patch("/assessor-aprovacoes/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: "ID inválido." }); return; }

    const [sol] = await db.select().from(solicitacoesTable).where(eq(solicitacoesTable.id, id));
    if (!sol) { res.status(404).json({ error: "Solicitação não encontrada." }); return; }

    const [pub] = await db.select().from(assessorPublicacoesTable).where(eq(assessorPublicacoesTable.solicitacao_id, id));
    if (!pub) { res.status(400).json({ error: "Este registro não passa por aprovação (sem página)." }); return; }

    const body = (req.body ?? {}) as Record<string, unknown>;
    const limpa = (v: unknown, max: number) => {
      const s = String(v ?? "").trim();
      return s ? s.slice(0, max) : null;
    };

    // so os campos que fazem sentido corrigir (e que afetam filtros)
    const nome = limpa(body.nome, 255);
    const codigo = limpa(body.codigo_assessor, 40);
    const unidade = limpa(body.unidade, 120);
    const contrato = limpa(body.contrato_social, 60);
    const foto = limpa(body.foto_url, 2000);

    // o dados_publicacao e a fonte da previa: mantem coerente com as colunas
    const dadosAtual = (pub.dados_publicacao || sol.dados || {}) as Record<string, any>;
    const dadosNovo = {
      ...dadosAtual,
      ...(nome !== null ? { nome_completo: nome, nome } : {}),
      ...(codigo !== null ? { codigo_assessor: codigo } : {}),
      ...(unidade !== null ? { unidade } : {}),
      ...(contrato !== null ? { contrato_social: contrato } : {}),
      ...(foto !== null ? { foto_url: foto, foto_perfil: foto } : {}),
    };

    await db.update(assessorPublicacoesTable).set({
      nome, codigo_assessor: codigo, unidade, contrato_social: contrato,
      ...(foto !== null ? { foto_url: foto } : {}),
      dados_publicacao: dadosNovo,
      editado_por_rh: true,
      atualizado_em: new Date(),
    }).where(eq(assessorPublicacoesTable.solicitacao_id, id));

    logger.info({ id, user: req.session?.user?.email }, "[assessor] perfil editado por admin");
    res.json({ ok: true });
  } catch (err: any) {
    logger.error({ err }, "[assessor] erro ao editar perfil");
    res.status(500).json({ error: "Não foi possível salvar as correções." });
  }
});

'''
    salvar(APR,a,a.replace(ANC,ENDPOINT+ANC,1),"[2a] OK — PATCH de edição (admin)")

# ═══ [2b] front: botao Editar + form ═══
v=io.open(VAL,encoding="utf-8").read()
if "vaEditar" in v:
    print("[2b] JA APLICADO.")
else:
    v0=v
    # botao "Editar dados" no rodape, visivel para admin em qualquer status editavel-por-admin
    # (aparece junto do bloco de acoes; usa Auth para checar admin)
    ANC_RODAPE="      const cabecalho ="
    if v.count(ANC_RODAPE)!=1: sys.exit("ABORTADO [2b]: ancora do cabecalho")
    BLOCO_EDIT = '''      // Admin pode corrigir os dados do perfil (ex.: contrato social errado),
      // independente do status — a correcao reflete nos filtros.
      const ehAdmin = (typeof Auth !== 'undefined' && Auth.getUserRole && Auth.getUserRole() === 'admin');
      if (aprovacao && ehAdmin) {
        rodape =
          '<div style="text-align:right;margin-bottom:8px">' +
            '<button class="btn btn-secondary" style="padding:4px 12px;font-size:0.78rem" onclick="abrirEdicao()">Editar dados</button>' +
          '</div>' + rodape;
      }

      const cabecalho ='''
    v=v.replace(ANC_RODAPE, BLOCO_EDIT, 1)

    # guarda os dados carregados para o form de edicao
    v=v.replace("      const resumo = data.resumo || {};",
                "      window._vaDados = data;   // guarda para a edição\n      const resumo = data.resumo || {};")

    # funcoes de edicao, ancoradas antes de "async function decidir"
    ANC_FN="    async function decidir(decisao) {"
    if v.count(ANC_FN)!=1: sys.exit("ABORTADO [2b]: ancora do decidir")
    FN_EDIT = '''    function abrirEdicao() {
      const d = (window._vaDados && window._vaDados.dados) || {};
      const contratos = (window._svnFormSchemas && window._svnFormSchemas.contratos) || [];
      const unidades = (typeof UNIDADES_SVN !== 'undefined' ? UNIDADES_SVN : []);
      const optSel = (arr, val, getV, getL) =>
        arr.map(function (o) {
          const vv = getV(o), ll = getL(o);
          return '<option value="' + esc(vv) + '"' + (String(vv) === String(val) ? ' selected' : '') + '>' + esc(ll) + '</option>';
        }).join('');

      const contratoOpts = '<option value="">Selecione</option>' +
        optSel(contratos, d.contrato_social, function (o) { return o.value != null ? o.value : o; }, function (o) { return o.label != null ? o.label : o; });
      const unidadeOpts = '<option value="">Selecione</option>' +
        optSel(unidades, d.unidade, function (o) { return o.nome != null ? o.nome : o; }, function (o) { return o.nome != null ? o.nome : o; });

      const campo = (lab, html) =>
        '<div style="margin-bottom:12px"><label style="display:block;font-size:0.74rem;color:var(--ink-50);margin-bottom:4px">' + lab + '</label>' + html + '</div>';
      const inp = (id, val) =>
        '<input id="' + id + '" style="width:100%;box-sizing:border-box;font:inherit;font-size:0.88rem;padding:8px 10px;border:1px solid var(--border-light);border-radius:var(--radius-md)" value="' + esc(val || '') + '">';
      const sel = (id, opts, extra) =>
        '<select id="' + id + '"' + (extra || '') + ' style="width:100%;box-sizing:border-box;font:inherit;font-size:0.88rem;padding:8px 10px;border:1px solid var(--border-light);border-radius:var(--radius-md)">' + opts + '</select>';

      const codAtual = String(d.codigo_assessor || '').replace(/^A/i, '');

      document.getElementById('vaDetalhe').innerHTML =
        '<div style="font-size:0.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ruby-red);margin-bottom:12px">Editar dados do perfil</div>' +
        campo('Nome completo', inp('edNome', d.nome_completo || d.nome)) +
        campo('Código do assessor', '<div style="display:flex;align-items:stretch"><span style="display:flex;align-items:center;padding:0 10px;border:1px solid var(--border-light);border-right:0;border-radius:var(--radius-md) 0 0 var(--radius-md);background:var(--icon-bg);color:var(--ink-60);font-weight:600">A</span><input id="edCodigo" inputmode="numeric" style="flex:1;min-width:0;font:inherit;font-size:0.88rem;padding:8px 10px;border:1px solid var(--border-light);border-radius:0 var(--radius-md) var(--radius-md) 0" value="' + esc(codAtual) + '" oninput="this.value=this.value.replace(/\\\\D/g,\\'\\')"></div>') +
        campo('Contrato social', sel('edContrato', contratoOpts)) +
        campo('Unidade', sel('edUnidade', unidadeOpts)) +
        '<div class="va-actions">' +
          '<button class="btn btn-primary" onclick="salvarEdicao()">Salvar correções</button>' +
          '<button class="btn btn-secondary" onclick="abrirDetalhe(detalheId)">Cancelar</button>' +
        '</div><div id="vaEditMsg" style="margin-top:10px;font-size:0.82rem"></div>';
      window._vaEditar = true;
    }

    async function salvarEdicao() {
      const msg = document.getElementById('vaEditMsg');
      msg.style.color = 'var(--ink-50)'; msg.textContent = 'Salvando…';
      const num = (document.getElementById('edCodigo').value || '').replace(/\\D/g, '');
      const payload = {
        nome: document.getElementById('edNome').value,
        codigo_assessor: num ? 'A' + num : '',
        contrato_social: document.getElementById('edContrato').value,
        unidade: document.getElementById('edUnidade').value,
      };
      try {
        const r = await fetch('/api/assessor-aprovacoes/' + detalheId, {
          method: 'PATCH', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const j = await r.json().catch(function () { return {}; });
        if (!r.ok) throw new Error(j.error || 'Falha ao salvar.');
        await abrirDetalhe(detalheId);   // recarrega com os dados novos
        await carregar();                // atualiza a lista/filtros
      } catch (e) {
        msg.style.color = 'var(--danger)'; msg.textContent = e.message || 'Erro ao salvar.';
      }
    }

    async function decidir(decisao) {'''
    v=v.replace(ANC_FN, FN_EDIT, 1)
    salvar(VAL,v0,v,"[2b] OK — botao Editar + formulario (admin)")

print("\nStop -> Run + bash check.sh")

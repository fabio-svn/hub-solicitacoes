#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Adequa o resumo do pedido para paginas de assessor:

[A] FLUXOS_ETAPAS ganha os tipos de assessor (o patch anterior nao entrou no pack).
    Dois fluxos distintos:
      - QUER pagina: Aguardando validacao -> Aprovado -> Concluido
      - NAO quer   : so "Concluido" (e registro, nao passa por aprovacao)

[B] Corrige o backend do GET /solicitacoes/:id (forms.ts):
    Hoje, quando NAO existe linha em assessor_publicacoes (= a pessoa nao quer
    pagina), meu codigo caia em "aguardando-validacao" — ERRADO: sem aprovacao,
    o correto e "concluido". Agora:
      - existe linha  -> usa o status dela  + expoe quer_pagina=sim
      - nao existe    -> status "concluido" + expoe quer_pagina=nao
    O resumo escolhe o fluxo pelo quer_pagina.

Idempotente, backups .bak-assresumo.
"""
import io, os, sys, glob, re

def _r(cs):
    for c in cs:
        p=os.path.normpath(c)
        if os.path.exists(p): return p
    return None
CFG=_r(["artifacts/api-server/public/config.js","public/config.js"])
ROTAS=glob.glob("artifacts/api-server/src/routes/*.ts")+glob.glob("src/routes/*.ts")
SOL=next((p for p in ROTAS if 'router.get("/solicitacoes/:id"' in io.open(p,encoding="utf-8").read()), None)
if not CFG or not SOL: sys.exit("arquivos nao encontrados")

def salvar(p, antes, depois, tag):
    b=p+".bak-assresumo"
    if not os.path.exists(b): io.open(b,"w",encoding="utf-8").write(antes)
    io.open(p,"w",encoding="utf-8").write(depois)
    print(tag)

# ═══ [A] FLUXOS_ETAPAS ═══
c=io.open(CFG,encoding="utf-8").read()
if "--registro" in c:   # marcador exclusivo do FLUXOS_ETAPAS de assessor
    print("[A] JA APLICADO.")
else:
    ANC="const FLUXOS_ETAPAS = {\n"
    if c.count(ANC)!=1: sys.exit("ABORTADO [A]: ancora FLUXOS_ETAPAS")
    COM_PAGINA=(
        '    { id: "aguardando-validacao", label: "Aguardando validação", visivel: true  },\n'
        '    { id: "aprovado",             label: "Aprovado",             visivel: true  },\n'
        '    { id: "publicado",            label: "Concluído",            visivel: true  },\n'
        '    { id: "ajustes-solicitados",  label: "Ajustes solicitados",  visivel: false },\n'
        '    { id: "reprovado",            label: "Reprovado",            visivel: false },\n'
    )
    # "nao quer pagina" = so registro. Uma unica etapa: Concluido.
    SO_REGISTRO=(
        '    { id: "concluido",            label: "Concluído",            visivel: true  },\n'
    )
    NOVO=(
        "const FLUXOS_ETAPAS = {\n"
        "  // Paginas de assessor NAO seguem o ClickUp. Ha dois casos:\n"
        "  //  - quer pagina  -> passa por validacao do RH e publicacao do marketing\n"
        "  //  - so registro  -> nao ha aprovacao, ja entra como concluido\n"
        '  "pagina-assessores-dados": [\n' + COM_PAGINA + "  ],\n"
        '  "pagina-assessores-dados--registro": [\n' + SO_REGISTRO + "  ],\n"
        '  "pagina-assessores-atualizacao": [\n' + COM_PAGINA + "  ],\n"
        '  "pagina-assessores-atualizacao--registro": [\n' + SO_REGISTRO + "  ],\n"
    )
    salvar(CFG, c, c.replace(ANC,NOVO,1), "[A] OK — fluxos de assessor (com pagina / so registro)")

# ═══ [B] backend: status + quer_pagina ═══
s=io.open(SOL,encoding="utf-8").read()
OLD='''    let statusPagina: string | null = null;
    if (["pagina-assessores-dados", "pagina-assessores-atualizacao"].includes(solicitacao.tipo_solicitacao)) {
      try {
        const [pubRow] = await db
          .select({ status: assessorPublicacoesTable.status })
          .from(assessorPublicacoesTable)
          .where(eq(assessorPublicacoesTable.solicitacao_id, id));
        statusPagina = pubRow?.status ?? "aguardando-validacao";
        (solicitacao as any).status = statusPagina;
      } catch { /* sem registro: mantem o status atual */ }
    }'''
if 'querPagina = "sim"' in s or 'querPagina = "nao"' in s:
    print("[B] JA APLICADO.")
    OLD = None
elif s.count(OLD)!=1:
    # tenta uma versao tolerante a espacos
    pat=re.compile(r'let statusPagina[\s\S]{0,600}?catch \{ /\* sem registro: mantem o status atual \*/ \}\s*\n    \}')
    if len(pat.findall(s))!=1:
        sys.exit("ABORTADO [B]: bloco statusPagina nao encontrado (ancora %d)"%s.count(OLD))
    alvo=pat.findall(s)[0]
    s=s.replace(alvo, "___PLACEHOLDER_B___",1)
    OLD="___PLACEHOLDER_B___"
NEW='''    // Paginas de assessor: o status vem da validacao/publicacao, nao do ClickUp.
    // E quem NAO quer pagina (so registro) nao passa por aprovacao: ja e "concluido".
    if (["pagina-assessores-dados", "pagina-assessores-atualizacao"].includes(solicitacao.tipo_solicitacao)) {
      try {
        const [pubRow] = await db
          .select({ status: assessorPublicacoesTable.status })
          .from(assessorPublicacoesTable)
          .where(eq(assessorPublicacoesTable.solicitacao_id, id));
        if (pubRow) {
          (solicitacao as any).status = pubRow.status;      // fluxo de validacao/publicacao
          (solicitacao as any).querPagina = "sim";
        } else {
          (solicitacao as any).status = "concluido";         // so registro, sem aprovacao
          (solicitacao as any).querPagina = "nao";
        }
      } catch { /* em caso de erro, mantem o status atual */ }
    }'''
if OLD and OLD in s:
    salvar(SOL, io.open(SOL,encoding="utf-8").read(), s.replace(OLD,NEW,1), "[B] OK — status certo + quer_pagina exposto")

print("\nStop -> Run + bash check.sh")
print("(o resumo escolhe o fluxo --registro quando querPagina=nao — ver patch do front)")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
No resumo do pedido (solicitacao.js), quando o tipo e pagina de assessor e a pessoa
NAO quer pagina (item.querPagina === "nao"), usa o fluxo "<tipo>--registro"
(apenas Concluido). Com pagina, segue o fluxo normal de validacao.

Idempotente, backup .bak-resumofront.
"""
import io, os, sys
def _r(cs):
    for c in cs:
        p=os.path.normpath(c)
        if os.path.exists(p): return p
    return None
J=_r(["artifacts/api-server/public/solicitacao.js","public/solicitacao.js"])
if not J: sys.exit("solicitacao.js nao encontrado")
s=io.open(J,encoding="utf-8").read()
if "--registro" in s:
    print("JA APLICADO."); sys.exit()

OLD='''      const tipoKey = item.tipo_solicitacao === 'eventos' ? 'eventos' : '_default';
      const fluxo = (typeof FLUXOS_ETAPAS !== 'undefined')
        ? (FLUXOS_ETAPAS[item.tipo_solicitacao] || FLUXOS_ETAPAS[tipoKey] || [])
        : [];'''
if s.count(OLD)!=1: sys.exit("ABORTADO: ancora %d vez(es)"%s.count(OLD))
NEW='''      const tipoKey = item.tipo_solicitacao === 'eventos' ? 'eventos' : '_default';
      // Paginas de assessor sem pedido de pagina sao so registro: fluxo enxuto (Concluído).
      let chaveFluxo = item.tipo_solicitacao;
      if (
        (item.tipo_solicitacao === 'pagina-assessores-dados' ||
         item.tipo_solicitacao === 'pagina-assessores-atualizacao') &&
        item.querPagina === 'nao'
      ) {
        chaveFluxo = item.tipo_solicitacao + '--registro';
      }
      const fluxo = (typeof FLUXOS_ETAPAS !== 'undefined')
        ? (FLUXOS_ETAPAS[chaveFluxo] || FLUXOS_ETAPAS[item.tipo_solicitacao] || FLUXOS_ETAPAS[tipoKey] || [])
        : [];'''
b=J+".bak-resumofront"
if not os.path.exists(b): io.open(b,"w",encoding="utf-8").write(s)
io.open(J,"w",encoding="utf-8").write(s.replace(OLD,NEW,1))
print("OK — resumo escolhe o fluxo --registro quando nao ha pedido de pagina")
